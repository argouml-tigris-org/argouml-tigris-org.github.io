Welcome to ArgoPDF!

ArgoPDF is a pdf report generation tool for ArgoUML.
All info about ArgoPDF you can find by visiting http://argopdf.tigris.org

To work with ArgoPDF in ArgoUML just put argopdf.jar file in ext directory,
itext-2.0.2.jar file to the same folder where argouml.jar file is situated 
and run/restart application.

ArgoPDF requires at least a JRE 1.5. Please let us know if you experience 
any JDK related problems.

How to work and start ArgoUML you can read in README.txt file of ArgoUML
or visit http://argouml.tigris.org

If you have any suggestions about improving ArgoPDF module you can write to
users@argopdf.tigris.org. 