package org.argouml.uml;

/**
 * Represents a folder in the ArgoPDF dialog tree, which contains all Use Case diagrams.
 * This class is just needed for finding an icon. 
 *
 * @author Dzmitry Churbanau
 * @version 0.1
 */
public class UseCases {
}
